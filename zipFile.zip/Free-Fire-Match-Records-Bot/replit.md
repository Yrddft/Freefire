# Free Fire Match Records Bot

A Python Discord bot that collects Free Fire match records, sends them to a
review channel, and publishes approved matches with their screenshots.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `cd bots/freefire-match-bot && python -m unittest discover -s tests -v` — run bot unit tests
- Render deployment is defined in the repository-root `render.yaml`
- Bot env: `DISCORD_BOT_TOKEN` (secret), `DATABASE_URL` (Render Postgres), and `APPROVAL_ROLE_ID`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Bot: Python 3.13, discord.py, asyncpg, and Render Postgres

## Where things live

- `bots/freefire-match-bot/freefire_bot/` — Discord commands, embeds, approval controls, and PostgreSQL access
- `bots/freefire-match-bot/README.md` — bot setup, permissions, and Render deployment steps
- `render.yaml` — Render background worker and Postgres Blueprint

## Architecture decisions

- Records stay pending until a member with the configured approval role approves them.
- PostgreSQL stores record data and Discord message references; approval copies the screenshot into the final post.
- Render supplies `DATABASE_URL`; the Replit bot token secret must be added separately in Render.

## Product

Server members submit match type, player mentions, and a result screenshot. Reviewers
approve or reject submissions in a designated channel. Only approved records appear
in the official records channel; player statistics use those approved records.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
